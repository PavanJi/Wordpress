=== Frontend posts creator ===
Contributors: Pavan (Shona)
Donate link: http://www.reviewrights.com 
Tags: frontend post creator, cpt post frontend, post, page , frontend post with thumbnail, frontend, frontend post, frontend edit, post, widget, posts, taxonomy
Requires at least: 2.7.0
Tested up to: 4.5.0
Stable tag: 1.0
License: GPL v2 or later
 
Simple light weighted pluing, use to create CPT post with thumnail from frontend. Use shortcode [Frontend_posts_creator].
  
== Description ==

WordPress Frontend Posts Creator Plugin enables simple full featured management of all type of post and cpt creating from frontend with post thumb.

Frontend post creator plugin create a form by using shortcode [Frontend_posts_creator]. This from fully customize by using shortcode Parameters.

<?php echo do_shortcode("[Frontend_posts_creator post_type='' post_status='' container='' container_class=''class='' id='' title_label='' title_placeholder='' content_label='' thumb_label='' submit_btn_id='' submit_btn_class='' submit_btn_label=''success_message='' error_message='' post_title_required='' post_thumb_error=''post_thumb_upload_error='' ]"); ?>

 post_type : Type of post/cpt(slug) . Value: Post type slug, Default: post

post_status : Post status . Value: draft/publish, Default: publish

container : Form wrap with in div. Value: TRUE/FALSE, Default: TRUE

container_class : Add your own class in wrapper div. Value: String, Default: fpc-form-wrap

class : Add your own class in form. Value: String, Default: fpc-form

id : Add your own id in form. Value: Single Word, Default: blank

title_label : Add your own title label in title field. Value: String, Default: Title

title_placeholder : Add your own title placeholder in title field. Value: String, Default: Your Title?

content_label : Add your own content label in content field. Value: String, Default: Content

thumb_label : Add your own thumbnail label in thumbnail field. Value: String, Default: Thumbnail

submit_btn_id : Add your own id in submit button field. Value: Single Word, Default: submit

submit_btn_class : Add your own class in submit button field. Value: String, Default: button button-primary

submit_btn_label : Add your own label in submit button field. Value: String, Default: Submit

post_title_required : Post title error message. Value: String, Default: Post title fields require.

post_thumb_error : Post thumbnail error message. Value: String, Default: Only image file is allowed.

post_thumb_upload_error : Post thumbnail uploading error message. Value: String, Default: File uploading error. Please check upload folder permission.

success_message : Success message after post inserted. Value: String, Default: Post published.

error_message : Error message after post form have error. Value: String, Default: Post publish error. 
   

 



== Installation ==

1. Download this plugin and upload into plugin folder.
2. Activate the plugin
3. Created a page and put shortcode in to post content [Frontend_posts_creator]
4: User <?php echo do_shortcode("[Frontend_posts_creator]"); ?> code in template file. 

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

== Upgrade Notice ==

None